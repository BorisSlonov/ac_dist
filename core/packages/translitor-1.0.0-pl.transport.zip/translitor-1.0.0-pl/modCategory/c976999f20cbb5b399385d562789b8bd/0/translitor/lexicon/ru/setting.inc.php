<?php

$_lang['area_translitor_main'] = 'Основные';

$_lang['setting_translitor_language'] = 'Язык-источник транслитерации';
$_lang['setting_translitor_languageg_desc'] = 'Указание языка необходимо для распознования особых символов языка';
